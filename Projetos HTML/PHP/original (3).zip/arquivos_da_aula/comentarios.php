<html>

<head>
    <meta charset="UTF-8">
    <title>Curso PHP</title>
</head>

<body>
    <!-- Comentário -->
    <?php
    // Comentário de uma linha
    echo 'Comando echo<br/>';

    # Comentário de uma linha
    echo print("Comando print<hr/>");

    /* 
    Comentário de multiplas linhas.
    Este tipo de comentário permite que várias
    linhas sejam comentadas ao mesmo tempo.
    */
    ?>
</body>

</html>