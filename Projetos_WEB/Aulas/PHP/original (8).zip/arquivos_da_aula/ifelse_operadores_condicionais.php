<html>

<head>
    <meta charset="UTF-8">
    <title>Curso PHP</title>
</head>

<body>
    <?php

        //== -> 2==2
        //=== -> são iguais e do mesmo tipo?
        //!= ou <> -> 'x' != 'y' ou 5 <> 6 (5 é diferente de 6?)
        //!== -> são diferentes e de tipos diferentes?
        // < -> 2 < 18  2 é menor que 18?
        if(2 === 2){
            echo 'Verdadeiro';
        } else {
            echo 'Falso';
        }

    ?>



</body>

</html>