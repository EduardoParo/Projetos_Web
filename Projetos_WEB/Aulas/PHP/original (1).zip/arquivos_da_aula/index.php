<html>

<head>
    <meta charset="UTF-8">
    <title>Curso PHP</title>
</head>

<body>
    <?php
        echo 'Utilizando a tag padrão';
    ?>
    <br/>
    <?= 'Utilizando a tag impressão' ?>

    <br/>
    <? echo 'Utilizando a tag curta'; ?>
</body>

</html>