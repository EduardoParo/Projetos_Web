<html>
	<head>
		<meta charset="utf-8" />
		<title>Curso PHP</title>
	</head>

	<body>
		<?php

			echo 'Comando echo<br/>';

			echo print("Comando print<hr/>")
		?>
	</body>
</html>