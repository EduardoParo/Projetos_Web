<html>

<head>
    <meta charset="UTF-8">
    <title>Curso PHP</title>
</head>

<body>
   <?php 
        echo 'Comando echo<br/>'; //contrutor da linguagem

        // print ("Comando print<hr/>"); //era uma função
       echo print ("Comando print<hr/>"); //retorna 1 se verdade.
   ?>
</body>

</html>